Contributions are welcome :)

Please add tests and run the linter.
